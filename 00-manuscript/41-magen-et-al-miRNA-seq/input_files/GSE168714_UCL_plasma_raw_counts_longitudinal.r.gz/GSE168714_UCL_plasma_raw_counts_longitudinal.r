
#################################
# setting the working directory #
#################################

#setwd("~/Google Drive/migration/EH") # the path will need to be changed!
setwd("C:/Users/IDDO/Google Drive/migration/EH")
myfile <- "Longitudinal_raw_counts_22_samples.txt"

#############################################
# reading the text file into an R dataframe #
#############################################

raw_counts <- read.table(myfile, header=TRUE, 
                         row.names=1, skip=3) 

metadata <- read.table(myfile, header=FALSE,
                       nrows=3, row.names=1, stringsAsFactors=FALSE)

colnames(metadata) <- colnames(raw_counts)

#################################
# filter out low coverage miRNA #
#################################

# option 1: keep only miRNA with at least 5 counts (sum across all samples)

#keep <- (rowSums(raw_counts)>=13000)>0
#filtered_counts2 <- raw_counts[keep,]#

# option 2: keep miRNAs with at least 50 counts in >60% of the samples
library(genefilter)
f1 <- pOverA(0.6, 50)
ffun <- filterfun(f1)
wh1 <- genefilter(raw_counts, ffun)
sum(wh1)
filtered_counts3 <- raw_counts[wh1,]
#other_miRNA <- as.vector(colSums(raw_counts)-colSums(filtered_counts3))
#filtered_counts3 <- rbind(filtered_counts3, other_miRNA)
#rownames(filtered_counts3)[nrow(filtered_counts3)] <- "other_miRNA" 
dim(filtered_counts3)

########################################
# define metadata variables as factors #
########################################

time <- metadata[1,]
time[time=="A"] <- 1
time[time=="B"] <- 2
time[time=="C"] <- 3
time[time=="D"] <- 4
time <- as.numeric(time)

subject <- as.character(metadata[2,])
subject <- factor(subject)
group <- as.character(metadata[3,])
group <- factor(group)

table(subject, time)
table(group, time)

#################################################
# define DESeq parameters countData and colData #
#################################################

library(DESeq2)
countData <- as.matrix(round(filtered_counts3)) 
colData <- data.frame (group, subject, time=factor(time)) # time as a factor

#############################################
# build the DESeq dataset with model design #
#############################################

dds <- DESeqDataSetFromMatrix(countData = countData,
                              colData = colData,
                              design = ~ time ) 


vst <- varianceStabilizingTransformation(dds, #blind=FALSE,
                                         fitType = "mean")
vstmat <- assay(vst)

plotPCA(vst, intgroup=c("group"))
plotPCA(vst, intgroup=c("time"))
plotPCA(vst, intgroup=c("subject"))

pow <- prcomp(t(vstmat))
screeplot(pow, type="l")

PC1 <- scale(pow$x[,1]) 
PC2 <- scale(pow$x[,2]) 
PC3 <- scale(pow$x[,3]) 
PC4 <- scale(pow$x[,4]) 
PC5 <- scale(pow$x[,5]) 
PC6 <- scale(pow$x[,6]) 

data <- data.frame(PC1, PC2, PC3, PC4, PC5, PC6, subject, time, group)

percentVar1 <- round(100 * summary(pow)$importance[2,1],1)
percentVar2 <- round(100 * summary(pow)$importance[2,2],1)
percentVar3 <- round(100 * summary(pow)$importance[2,3],1)
percentVar4 <- round(100 * summary(pow)$importance[2,4],1)
percentVar5 <- round(100 * summary(pow)$importance[2,5],1)
percentVar6 <- round(100 * summary(pow)$importance[2,6],1)

pdf("R1-R80.pdf")

set.seed(42)
library(ggplot2)
library(ggrepel)

pdf("PCA plots by subject and group.pdf", width=9, height=6)

for (i in 1:5) {
  dff <- data[,c(i,i+1,7:9)]
  colnames(dff)[1] <- paste0("PC1")
  colnames(dff)[2] <- paste0("PC2")
  
g <- ggplot(dff, aes(PC1, PC2, color=subject, label=subject)) +
  geom_point(size=3) +
  geom_text_repel(size=2.0) +
  facet_wrap(~group) +
  #geom_text_repel(aes(logFC, log2FoldChange, label = gsub("hsa-miR-","",mirnas))
  #                , size=1.5,
  #                data = subset(NK_res, logFC < (-2) | logFC >-1.25)) +
  xlab(paste0("PC",i)) +#,": ",percentVar1,"% variance")) +
  ylab(paste0("PC",i+1)) + #: ",percentVar2,"% variance")) +
theme(legend.position="none")

print(g)
}

dev.off()

for (i in 1:6) {
  dff <- data[,c(i,7:9)]
  colnames(dff)[1] <- "PC"
g <- ggplot(dff, aes(x=group, y=PC, color=group)) +
  geom_boxplot() +
  ylab(paste0("PC ",i))
print(g)
}

pdf("PCs by subject.pdf", width=8, height=3)
for (i in 1:6) {
  dff <- data[,c(i,7:9)]
  colnames(dff)[1] <- "PC"
  g <- ggplot(dff, aes(x=subject, y=PC, color=group)) +
    geom_boxplot() +
    ylab(paste0("PC ",i)) +
    theme(axis.text.x = element_text(angle = 90, hjust = 1))
  print(g)
}

dev.off()

##########
# ComBat #
##########

# this will cancel out the patient ("subject") instead of introducing as blocking factor in the model

library(sva)
library(edgeR)

cpmdata = cpm(filtered_counts3, log=TRUE, normalized.lib.sizes=FALSE, prior.count=0.25)
modcombat = model.matrix(~time, group, data=data.frame(t(cpmdata)))
combat_edata = ComBat(dat=cpmdata, batch=subject, mod=modcombat, par.prior=FALSE,
                      prior.plots=TRUE)
revertdata = t(((2^t(combat_edata))*colSums(filtered_counts3)/1000000)-0.25)
revertdata[revertdata<0] <- 0
write.csv(revertdata, file="Batch_corrected_longitudinal_group_new.csv")

#################################################
# define DESeq parameters countData and colData #
#################################################

library(DESeq2)
countData <- as.matrix(round(revertdata)) 
colData <- data.frame (group, subject, Time=factor(time)) # time as a factor

#############################################
# build the DESeq dataset with model design #
#############################################

dds <- DESeqDataSetFromMatrix(countData = countData,
                              colData = colData,
                              design = ~ Time ) 

###########################################
# DESeq2 differential expression analysis #
###########################################

dds <- DESeq(dds, test="LRT", reduced=~1, fitType="mean") # ANOVA-like model

###############################################
# extract the differential expression results #
###############################################

resultsNames(dds)
res <- results(dds, contrast=c(0,0,0,1), alpha=0.05) # the log2FC that will be shown are the average
# of time 2 vs 1, 3 vs 1 and 4 vs 1; but the p-value shown are the overall ANOVA-like p-vals
summary(res)
write.csv(res, file="t4 vs t1 simple filtering 2.csv")


View(data.frame(res))
write.csv(res, file="t2 vs t1 for comparison with cfDNA.csv")
DESeq2::plotMA(res)


tags <- rownames(res)[res$padj<0.05]

vstmat <- assay(vst(dds, blind="FALSE", fitType="mean"))

library(ggplot2)


g <- list()
for (i in tags) {
  df <- data.frame(miRNA=vstmat[i,], timepoint=factor(time), group=group)
g[[i]] <-  ggplot(df, aes(x=timepoint, y=miRNA)) +
    geom_boxplot(notch=TRUE) +
  ylab(i) +
   facet_wrap(~group) +
  geom_dotplot(binaxis='y', stackdir='center', dotsize = .5, fill="yellow")
#print(g)
}

library(gridExtra)

gs <- do.call("grid.arrange", c(g, ncol=3))
ggsave(file="grid DESeq2 tags patient-adjusted raw counts by treatment with dots.pdf", gs,
       width=10.9, height=70, limitsize = FALSE) #saves g


# miRNA-based score

up <- rownames(res)[res$log2FoldChange>0 & res$pvalue<.05]
dn <- rownames(res)[res$log2FoldChange<0 & res$pvalue<.05]

updata <- vstmat[up,]
dndata <- -vstmat[dn,]

tdata <- rbind(updata,dndata)

stdata <- t(scale(t(tdata)))
score <- apply(stdata,2,sum)

df <- data.frame(score, Time=factor(time), group)
library(ggplot2)
library(ggsignif)
ggplot(df , aes(x=Time, y=score)) +
  facet_wrap(~group) +
  geom_boxplot(notch = TRUE, outlier.colour = NA)+
  geom_dotplot(binaxis='y', stackdir='center', dotsize = .5, fill="yellow")


# now the same again but with time as numeric, not a factor

colData <- data.frame (group, subject, time) 

#############################################
# build the DESeq dataset with model design #
#############################################

dds.2 <- DESeqDataSetFromMatrix(countData = countData,
                              colData = colData,
                              design = ~ time:group ) 

###########################################
# DESeq2 differential expression analysis #
###########################################

dds.2 <- DESeq(dds.2, fitType="mean") 

###############################################
# extract the differential expression results #
###############################################

resultsNames(dds.2)
res.2 <- results(dds.2, contrast=c(0,0,0,1)) # the log2FC are per increase of 1 unit of time
View(data.frame(res.2))
#write.csv(res.2, file="all samples time as numeric revertdata.csv")
tags.2 <- rownames(res.2)[res.2$padj<0.05]

up <- rownames(res.2)[res.2$log2FoldChange>0 & res.2$pvalue<.05]
dn <- rownames(res.2)[res.2$log2FoldChange<0 & res.2$pvalue<.05]

updata <- vstmat[up,]
dndata <- -vstmat[dn,]

tdata <- rbind(updata,dndata)

stdata <- t(scale(t(tdata)))
score <- apply(stdata,2,sum)

df <- data.frame(score, Time=factor(time), group)
library(ggplot2)
ggplot(df , aes(x=Time, y=score)) +
  facet_wrap(~group) +
  geom_boxplot(notch = TRUE, outlier.colour = NA)+
  geom_dotplot(binaxis='y', stackdir='center', dotsize = .5, fill="yellow")



#########
# edgeR #
#########

Time <- factor(time)

library(edgeR)
design=model.matrix(~time:group)
colnames(design)
dge <- DGEList(counts = revertdata) 
dge <- calcNormFactors(dge, method="TMM", design=design)

y <- estimateDisp(dge, design)
fit <- glmFit(y, design)
#lrt.234vs1 <- glmLRT(fit, coef=2:4)
lrt.t <- glmLRT(fit, coef=4)
#edge2 <- data.frame(topTags(lrt.234vs1, n=nrow(dge), sort.by = "none"))
edge2 <- data.frame(topTags(lrt.t, n=nrow(dge), sort.by = "none"))

View(edge2)

#write.csv(edge2, file="edgeR timepoint 2-3-4 vs 1 with revertdata.csv")

tags.3 <- rownames(edge2)[edge2$FDR<0.05]

library(ggplot2)

g <- list()
for (i in tags.3) {
  df <- data.frame(miRNA=combat_edata[i,], timepoint=Time, group=group)
  g[[i]] <-  ggplot(df, aes(x=timepoint, y=miRNA)) +
    geom_boxplot(notch=TRUE) +
    ylab(i) +
  facet_wrap(~group)
  #print(g)
}

library(gridExtra)

gs <- do.call("grid.arrange", c(g, ncol=3))
ggsave(file="grid edgeR by fast tags subject-adjusted raw counts.pdf", gs,
       width=10.9, height=6, limitsize = FALSE) #saves g

#
