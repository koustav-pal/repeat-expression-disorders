### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ###
###                      ALS progression study                                          ###
### Comparison to Henk-Jan Westeneng, Thomas Debray et al., (2018, Lancet Neurology).   ###
###                                                                                     ###
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ###

# This code runs with  "R version 4.0.3 (2020-10-10)"

#------------------------------------------------------------------#
# Loading required packages
library (survival)
library(survminer)
library (forestmodel)

#------------------------------------------------------------------#
# Set constants and pats
set.seed(111)

is_nancy = FALSE # Iddo, replace to "is_nancy=FALSE" when you run the code

# set here your directory with the data 
if (is_nancy) {
  setwd("~/PycharmProjects/HornLab/HornLab/Iddo_miRNA/ALS/prognostic_miRNA/code/R/")
} else {
  setwd("~/Google Drive/EH") # the path will need to be changed!
}

print(getwd())

#------------------------------------------------------------------#
#------------------------------------------------------------------#

#------------------------------------------------------------------#
# Path to data files
data_file_discovery = "Data_file_related_to_fig_2_3_5_discovery.csv"
data_file_replication = "Data_file_related_to_fig_3_5_replication.csv"


#------------------------------------------------------------------#
# Functions
#------------------------------------------------------------------#

build_cox_westeneng <- function(data, survival_column, plot_name) {
  
  # 8 Predictors selected in Westeneng: 
  # age at onset (years), diagnostic delay (months), FVC%, bulbar onset, 
  # revised El Escorial criteria (definite vs probable or possible ALS), FTD, c9.
  # Outcome: very short; short; intermediate; long; and very long.
  
  westeneng_predictors = c("Age_at_onset", "FVC", "diagnostic_delay", "slope", 
                           "onset", "El_escorial", "cognitive", "C9ORF72")
  
  
  westeneng_x = paste(westeneng_predictors, collapse = " + ")
  
  
  y = paste("Surv(",survival_column,", status)", sep = "")
  
  westeneng_model_formula = as.formula(paste(y, "~", westeneng_x))
  print(westeneng_model_formula)
  
  #------------------------------------------------------------------#
  #------------------------------------------------------------------#
  #------------------------------------------------------------------#
  # COPX-PH on all features from Westeneng - WITHOUT mir_181a_b!!
  westeneng.features.cox <- coxph(formula=westeneng_model_formula, data=data)
  
  # Forest plot for Cox
  plt1 <- forest_model(westeneng.features.cox, return_data = F)
  # Save plot to pdf file
  pdf(plot_name)
  print(plt1)
  dev.off()
  
  
  print(summary(westeneng.features.cox))
  
  # The concordance-index of the FULL model 
  print("\nconcordance: ")
  print(westeneng.features.cox$concordance['concordance'])
  
  print("\nAIC: ")
  AIC(westeneng.features.cox) 
  print(AIC(westeneng.features.cox))
  
  
  # Test the proportional hazards assumption for a Cox regression model fit (coxph).
  westeneng.features.prop.test.ph <- cox.zph(westeneng.features.cox)
  print("\nTesting proportional hazards assumption:")
  print(westeneng.features.prop.test.ph)
  # a plot of Schoenfeld residuals
  #plot(westeneng.features.prop.test.ph)
  
  # return the cox model
  westeneng.features.cox
}

build_cox_NfL_mir_181 <- function(data, survival_column, plot_name) {
  
  all_x_names = c("NfL_181")
  
  all_x = paste(all_x_names, collapse = " + ")
  
  y = paste("Surv(",survival_column,", status)", sep = "")
  
  full_model_formula = as.formula(paste(y, "~", all_x))
  print(full_model_formula)
  
  #------------------------------------------------------------------#
  #------------------------------------------------------------------#
  #------------------------------------------------------------------#
  # COPX-PH on NfL_mir_181a_b !!
  NfL_181.cox <- coxph(formula=full_model_formula, data=data)
  
  # Forest plot for Cox
  plt2 <- forest_model(NfL_181.cox, return_data = F)
  # Save plot to pdf file
  pdf(plot_name)
  print(plt2)
  dev.off()
  
  
  print(summary(NfL_181.cox))
  
  # The concordance-index of the FULL model 
  print("\nconcordance: ")
  print(NfL_181.cox$concordance['concordance'])
  print("\nAIC: ")
  print(AIC(NfL_181.cox))
  
  # Test the proportional hazards assumption for a Cox regression model fit (coxph).
 NfL_181.prop.test.ph <- cox.zph(NfL_181.cox)
  print("Testing proportional hazards assumption:")
  print(NfL_181.prop.test.ph)
  # a plot of Schoenfeld residuals
  #plot(all.features.prop.test.ph)
  
  # return the cox model
  NfL_181.cox
}

build_cox_NfL_mir_181_westeneng <- function(data, survival_column, plot_name) {
  
  all_x_names = c("NfL_181", "Age_at_onset", "FVC", "diagnostic_delay", "slope", 
                  "onset", "El_escorial", "cognitive", "C9ORF72")
  
  all_x = paste(all_x_names, collapse = " + ")
  
  y = paste("Surv(",survival_column,", status)", sep = "")
  
  full_model_formula = as.formula(paste(y, "~", all_x))
  print(full_model_formula)
  
  #------------------------------------------------------------------#
  #------------------------------------------------------------------#
  #------------------------------------------------------------------#
  # COPX-PH on NfL_mir_181a_b and all features from Westeneng !!
  all.features.cox <- coxph(formula=full_model_formula, data=data)
  
  # Forest plot for Cox
  plt2 <- forest_model(all.features.cox, return_data = F)
  # Save plot to pdf file
  pdf(plot_name)
  print(plt2)
  dev.off()
  
  
  print(summary(all.features.cox))
  
  # The concordance-index of the FULL model (from onset)
  print("\nconcordance: ")
  print(all.features.cox$concordance['concordance'])
  print("\nAIC: ")
  print(AIC(all.features.cox))
  
  # Test the proportional hazards assumption for a Cox regression model fit (coxph).
  all.features.prop.test.ph <- cox.zph(all.features.cox)
  print("Testing proportional hazards assumption:")
  print(all.features.prop.test.ph)
  # a plot of Schoenfeld residuals
  #plot(all.features.prop.test.ph)
  
  # return the cox model
  all.features.cox
}

#------------------------------------------------------------------#
###                         DISCOVERY                            ###
#------------------------------------------------------------------#
#------------------------------------------------------------------#

# Load discovery data 
data <- read.csv(file = data_file_discovery)

#head(data) 
dim(data) # 126 x 56

#------------------------------------------------------------------#
###                         REPLICATION                          ###
#------------------------------------------------------------------#
# Load REPLICATION data 
replication_data <- read.csv(file = data_file_replication)

#head(replication_data) 
dim(replication_data) # 122 x 56

#------------------------------------------------------------------#
###                         REPLICATION                          ###
###   Get the selected features, and test them on replicaton    ###
#------------------------------------------------------------------#


# Combine discovery and replication cohorts 
all_data = rbind(data, replication_data)
dim(all_data) # 248 x 56

write.csv(all_data, file="new merged data.csv")

# Keep only those with NfL data
partial_data_NfL <- all_data[complete.cases(all_data[,'NfL_binary']),]
dim(partial_data_NfL)

# Keep only those with Westeneng measurements
feature_names <- c('NfL_binary', 'FVC', 'C9ORF72', 'El_escorial', 'cognitive','NfL_181')
partial_data <- all_data[complete.cases(all_data[, feature_names]),]
dim(partial_data) # 75  56

#------------------------------------------------------------------#
#------------------------------------------------------------------#


### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ###
###             ALS survival from ENROLMENT                 ###
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ###

# cox model only with westeneng features 
westeneng.features.cox.enrolment = build_cox_westeneng(data=partial_data,
                                                      survival_column = "survival_enrolment",
                                                      plot_name = "HR_COPXPH_from_enrolment_on_westeneng_features_WITHOUT_NfL_181.pdf")
# concordance 0.7504607 
# AIC: 441.5586
#------------------------------------------------------------------#
#------------------------------------------------------------------#

# cox model only with  NFL_mir_181
NfL_181.cox.enrolment = build_cox_NfL_mir_181(data=partial_data,
                                                 survival_column = "survival_enrolment",
                                                 plot_name = "HR_COPXPH_from_enrolment_on_NfL_181.pdf")
# concordance 0.6730557 
# AIC 444.3773
#------------------------------------------------------------------#
#------------------------------------------------------------------#

# cox model with westeneng features AND  NFL_mir_181

all.features.cox.enrolment = build_cox_NfL_mir_181_westeneng(data=partial_data,
                                                              survival_column = "survival_enrolment",
                                                              plot_name = "HR_COPXPH_from_enrolment_on_westeneng_features_WITH_NfL_181.pdf")

# concordance 0.7718393
# AIC 433.6027
#------------------------------------------------------------------#
#------------------------------------------------------------------#


#------------------------------------------------------------------#
# END OF ANALYSIS FROM ENROLMENT-----------------------------------#
#------------------------------------------------------------------#



####################################################################
####################################################################

# Plot the KM survival Curve (the observed survival, with no predictors) VS. the predicted survival curve by multivariate cox-ph 

extract_survival_probability_from_cox_model1 <- function(model, model_name) {
  
  # get the time points of this model
  x = summary(survfit(empty.cox.enrolment, se.fit=F))$time
  # get the survival probability of this model to each time point
  y = summary(survfit(empty.cox.enrolment, se.fit=F))$surv * 100
  
  # create a data frame and save it to file
  temp_data1 <- data.frame(x, y)
  colnames(temp_data1) <- c('time', 'surv prob')
  file_name = paste0("time_vs_survival_probability_", model_name)
  write.csv(temp_data1, file=file_name)
  
  temp_data1
}

extract_survival_probability_from_cox_model2 <- function(model, model_name) {
  
  # get the time points of this model
  x = summary(survfit(westeneng.features.cox.enrolment, se.fit=F))$time
  # get the survival probability of this model to each time point
  y = summary(survfit(westeneng.features.cox.enrolment, se.fit=F))$surv * 100
  
  # create a data frame and save it to file
  temp_data2 <- data.frame(x, y)
  colnames(temp_data2) <- c('time', 'surv prob')
  file_name = paste0("time_vs_survival_probability_", model_name)
  write.csv(temp_data2, file=file_name)
  
  temp_data2
}

extract_survival_probability_from_cox_model3 <- function(model, model_name) {
  
  # get the time points of this model
  x = summary(survfit(NfL_181.cox.enrolment, se.fit=F))$time
  # get the survival probability of this model to each time point
  y = summary(survfit(NfL_181.cox.enrolment, se.fit=F))$surv * 100
  
  # create a data frame and save it to file
  temp_data3 <- data.frame(x, y)
  colnames(temp_data3) <- c('time', 'surv prob')
  file_name = paste0("time_vs_survival_probability_", model_name)
  write.csv(temp_data3, file=file_name)
  
  temp_data3
}



# custom function made by Nancy, to control the CI shading
plot_surv_curves_with_ci <- function(fitted_cox_1, fitted_cox_2, fitted_cox_3, plot_title, legend=NULL) {
  
  if(is.null(legend)) {
    legend = c("Observed (real) survival", "Survival predicted by clinical covariates",  "Survival predicted by NfL_181")
  }
  
  # get all relevant data (time, surv, upper, lower) for each cox model
  mod1 <- summary(survfit(fitted_cox_1, se.fit=F))
  mod2 <- summary(survfit(fitted_cox_2, se.fit=T))
  mod3 <- summary(survfit(fitted_cox_3, se.fit=T))
  
  #  use function plot() to define the plotting region. 
  with(mod1, 
       with(mod1, plot(time,
                      surv, 
                      type="n",
                      #xlim=c(0, 120),
                      ylim=c(0,1),
                      xlab="Survival from enrolment (months)",
                      ylab="Perecent survival", 
                      main=plot_title
       )))
  
  # Then with polygon() plot confidence interval. 
  with(mod2, polygon(c(time, rev(time)), #  x values: provide time values and time values in reverse order, 
                    c(lower,rev(upper)), #  y values: use lower values and revere upper values. 
                    col = "grey85", 
                    border = FALSE))
  
  with(mod3, polygon(c(time, rev(time)), #  x values: provide time values and time values in reverse order, 
                     c(lower,rev(upper)), #  y values: use lower values and revere upper values. 
                     col = "grey70", 
                     border = FALSE))
  
  # Draw the survival curve function lines()  
  # By adding argument type="s" to lines() you will get line as steps.
  with(mod1, lines(time, surv, col="firebrick2", lwd=2))  
  
  with(mod2, lines(time, surv, col="royalblue1", lwd=2)) 
  
  with(mod3, lines(time, surv, col="forestgreen", lwd=2)) 
  
  legend(25, 0.85, 
         lty=1:1, cex=0.8,
         legend=legend,
         col=c("firebrick2", "royalblue1","forestgreen"))

}

# --------------------------------------------------------
# Calcualting the observed survival probabilities
# The empty survival model with no predictors
survival_column = "survival_enrolment"
y = paste("Surv(",survival_column,", status)", sep = "")
empty_model_formula = as.formula(paste(y, "~", "1"))
empty.cox.enrolment <- coxph(formula=empty_model_formula, data=partial_data)

extract_survival_probability_from_cox_model1(model=empty.cox.enrolment, 
                                            model_name='observed_enrolment')

extract_survival_probability_from_cox_model2(model=westeneng.features.cox.enrolment, 
                                            model_name='predicted_westeneng_enrolment')

extract_survival_probability_from_cox_model3(model=NfL_181.cox.enrolment, 
                                            model_name="predicted_NfL_181_enrolment")
# --------------------------------------------------------
# Observed vs. Multivariate cox with Westeneng features and vs univariate cox with NfL_181  
plot_surv_curves_with_ci(fitted_cox_1 = empty.cox.enrolment,
                         fitted_cox_2 = westeneng.features.cox.enrolment, 
                         fitted_cox_3 = NfL_181.cox.enrolment,
                         plot_title = "Distribution of survival times from enrolment: \nKM curve (observed survival) vs. predicted survival curves")

####################################################################
#------------------------------------------------------------------#
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ###
###             ALS survival from ONSET                 ###
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ###

#------------------------------------------------------------------#
#------------------------------------------------------------------#

westeneng.features.cox.onset = build_cox_westeneng(data=partial_data,
                                                   survival_column = "survival_onset",
                                                   plot_name = "HR_COPXPH_from_onset_on_westeneng_features_WITHOUT_NfL_miR_181.pdf")

# concordance  0.8097983 
#------------------------------------------------------------------#
#------------------------------------------------------------------#

# with NfL_mir_181

all.features.cox.onset = build_cox_NfL_mir_181_westeneng(data=partial_data,
                                                        survival_column = "survival_onset",
                                                        plot_name = "HR_COPXPH_from_onset_on_westeneng_features_WITH_NfL_181.pdf")


# only NfL_mir_181

NfL_181.cox.onset = build_cox_NfL_mir_181(data=partial_data,
                                                            survival_column = "survival_onset",
                                                            plot_name = "HR_COPXPH_from_onset_on_NfL_181.pdf")


# concordance  0.824 
 
#------------------------------------------------------------------#
# END OF ANALYSIS FROM ONSET    -----------------------------------#
#------------------------------------------------------------------#

####################################################################


extract_survival_probability_from_cox_model4 <- function(model, model_name) {
  
  # get the time points of this model
  x = summary(survfit(empty.cox.onset, se.fit=F))$time
  # get the survival probability of this model to each time point
  y = summary(survfit(empty.cox.onset, se.fit=F))$surv * 100
  
  # create a data frame and save it to file
  temp_data4 <- data.frame(x, y)
  colnames(temp_data4) <- c('time', 'surv prob')
  file_name = paste0("time_vs_survival_probability_", model_name)
  write.csv(temp_data4, file=file_name)
  
  temp_data4
}

extract_survival_probability_from_cox_model5 <- function(model, model_name) {
  
  # get the time points of this model
  x = summary(survfit(westeneng.features.cox.onset, se.fit=F))$time
  # get the survival probability of this model to each time point
  y = summary(survfit(westeneng.features.cox.onset, se.fit=F))$surv * 100
  
  # create a data frame and save it to file
  temp_data5 <- data.frame(x, y)
  colnames(temp_data5) <- c('time', 'surv prob')
  file_name = paste0("time_vs_survival_probability_", model_name)
  write.csv(temp_data5, file=file_name)
  
  temp_data5
}

extract_survival_probability_from_cox_model6 <- function(model, model_name) {
  
  # get the time points of this model
  x = summary(survfit(NfL_181.cox.onset, se.fit=F))$time
  # get the survival probability of this model to each time point
  y = summary(survfit(NfL_181.cox.onset, se.fit=F))$surv * 100
  
  # create a data frame and save it to file
  temp_data6 <- data.frame(x, y)
  colnames(temp_data6) <- c('time', 'surv prob')
  file_name = paste0("time_vs_survival_probability_", model_name)
  write.csv(temp_data6, file=file_name)
  
  temp_data6
}



# custom function made by Nancy, to control the CI shading
plot_surv_curves_with_ci <- function(fitted_cox_1, fitted_cox_2, fitted_cox_3, plot_title, legend=NULL) {
  
  if(is.null(legend)) {
    legend = c("Observed (real) survival", "Survival predicted by clinical covariates",  "Survival predicted by NfL_181")
  }
  
  # get all relevant data (time, surv, upper, lower) for each cox model
  mod1 <- summary(survfit(fitted_cox_1, se.fit=F))
  mod2 <- summary(survfit(fitted_cox_2, se.fit=T))
  mod3 <- summary(survfit(fitted_cox_3, se.fit=T))
  
  #  use function plot() to define the plotting region. 
  with(mod1, 
       with(mod1, plot(time,
                       surv, 
                       type="n",
                       #xlim=c(0, 120),
                       ylim=c(0,1),
                       xlab="Survival from enrolment (months)",
                       ylab="Perecent survival", 
                       main=plot_title
       )))
  
  # Then with polygon() plot confidence interval. 
  with(mod2, polygon(c(time, rev(time)), #  x values: provide time values and time values in reverse order, 
                     c(lower,rev(upper)), #  y values: use lower values and revere upper values. 
                     col = "grey85", 
                     border = FALSE))
  
  with(mod3, polygon(c(time, rev(time)), #  x values: provide time values and time values in reverse order, 
                     c(lower,rev(upper)), #  y values: use lower values and revere upper values. 
                     col = "grey70", 
                     border = FALSE))
  
  # Draw the survival curve function lines()  
  # By adding argument type="s" to lines() you will get line as steps.
  with(mod1, lines(time, surv, col="firebrick2", lwd=2))  
  
  with(mod2, lines(time, surv, col="royalblue1", lwd=2)) 
  
  with(mod3, lines(time, surv, col="forestgreen", lwd=2)) 
  
  legend(25, 0.85, 
         lty=1:1, cex=0.8,
         legend=legend,
         col=c("firebrick2", "royalblue1","forestgreen"))
  
}

# --------------------------------------------------------
# Calcualting the observed survival probabilities
# The empty survival model with no predictors
survival_column = "survival_onset"
y = paste("Surv(",survival_column,", status)", sep = "")
empty_model_formula = as.formula(paste(y, "~", "1"))
empty.cox.onset <- coxph(formula=empty_model_formula, data=partial_data)

extract_survival_probability_from_cox_model4(model=empty.cox.onset, 
                                             model_name='observed_onset')

extract_survival_probability_from_cox_model5(model=westeneng.features.cox.onset, 
                                             model_name='predicted_westeneng_onset')

extract_survival_probability_from_cox_model6(model=NfL_181.cox.onset, 
                                             model_name="predicted_NfL_181_onset")
# --------------------------------------------------------
# Observed vs. Multivariate cox with Westeneng features and vs univariate cox with NfL_181  
plot_surv_curves_with_ci(fitted_cox_1 = empty.cox.onset,
                         fitted_cox_2 = westeneng.features.cox.onset, 
                         fitted_cox_3 = NfL_181.cox.onset,
                         plot_title = "Distribution of survival times from enrolment: \nKM curve (observed survival) vs. predicted survival curves")
